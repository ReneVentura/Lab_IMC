package com.example.imc

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val calcular : Button = findViewById(R.id.ClcBtn)
        calcular.setOnClickListener{

            val Peso = PesoTxt.text.toString().toDouble()* 0.454
            val Estatura= EstTxT.text.toString().toDouble()/100

            if(Peso >= 3000 || Estatura>= 270){
                Toast.makeText(this, "Ingrese peso entre 0 o 3000, Ingrese estatura entrer 0 o 270", Toast.LENGTH_SHORT).show()


            }
            else{
                val IMC= Peso/(Estatura*Estatura)
                val re= "Su IMC es: "+IMC
                val intent: Intent= Intent(this, Resultado::class.java)
                intent.putExtra("IMC",re)
                startActivity(intent)

            }




        }

    }


}
